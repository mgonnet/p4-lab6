/*
 * Parametro.h
 *
 *  Created on: 11/06/2014
 *      Author: matias
 */

#ifndef PARAMETRO_H_
#define PARAMETRO_H_

class Parametro
{
private:
	virtual void dummy()=0;

public:
	virtual ~Parametro();
};


#endif /* PARAMETRO_H_ */
