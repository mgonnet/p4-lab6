/*
 * Observer.cpp
 *
 *  Created on: 11/06/2014
 *      Author: matias
 */

#include "../../headers/clases/Observer.h"

Observer::Observer() { }

Observer::~Observer(){ }

