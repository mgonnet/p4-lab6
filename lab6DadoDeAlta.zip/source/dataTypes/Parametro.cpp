/*
 * Parametro.cpp
 *
 *  Created on: 12/06/2014
 *      Author: matias
 */

#include "../../headers/dataTypes/Parametro.h"

Parametro::~Parametro() { }

