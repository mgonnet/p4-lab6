#ifndef ROL_H_
#define ROL_H_

enum Rol { ADMIN, MEDICO, SOCIO };

#endif /* ROL_H_ */
