/*
 * TipoConsulta.h
 *
 *  Created on: 09/06/2014
 *      Author: GRUPO_04
 */

#ifndef TIPOCONSULTA_H_
#define TIPOCONSULTA_H_

enum TipoConsulta { COMUN,
					EMERGENCIA };


#endif /* TIPOCONSULTA_H_ */
