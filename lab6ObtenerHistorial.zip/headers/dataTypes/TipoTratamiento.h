/*
 * TipoTratamiento.h
 *
 *  Created on: 09/06/2014
 *      Author: GRUPO_04
 */

#ifndef TIPOTRATAMIENTO_H_
#define TIPOTRATAMIENTO_H_

enum TipoTratamiento {	QUIRURGICO,
						FARMACOLOGICO };

#endif /* TIPOTRATAMIENTO_H_ */
