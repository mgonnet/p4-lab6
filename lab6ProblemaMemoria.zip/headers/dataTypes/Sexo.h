/*
 * Sexo.h
 *
 *  Created on: 03/05/2014
 *      Author: GRUPO_04
 */

#ifndef SEXO_H_
#define SEXO_H_

enum Sexo { FEMENINO, MASCULINO };


#endif /* SEXO_H_ */
