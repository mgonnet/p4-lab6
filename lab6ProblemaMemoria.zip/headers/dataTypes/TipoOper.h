/*
 * TipoOper.h
 *
 *  Created on: 12/06/2014
 *      Author: sac
 */

#ifndef TIPOOPER_H_
#define TIPOOPER_H_


enum TipoOper { ALTA, REACTIVACION };


#endif /* TIPOOPER_H_ */
