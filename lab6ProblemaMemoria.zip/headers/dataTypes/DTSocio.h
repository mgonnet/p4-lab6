/*
 * DTSocio.h
 *
 *  Created on: 09/06/2014
 *      Author: GRUPO_04
 */

#ifndef DTSOCIO_H_
#define DTSOCIO_H_

#include <string>

#include "FechaHora.h"

using namespace std;

class DTSocio
{
	string	ci;
	string	nombre;
	string	apellido;
	Fecha	fehcaNac;
};

#endif /* DTSOCIO_H_ */
