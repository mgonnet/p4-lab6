/*
 * LineaRegistroAR.cpp
 *
 *  Created on: 19/06/2014
 *      Author: matias
 */

#include "../../headers/clases/LineaRegistroAR.h"

LineaRegistroAR::LineaRegistroAR(Fecha fecha, TipoOper tipoOper):
	fecha(fecha),
	tipoOper(tipoOper)
{}
